package com.hrs.bi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
