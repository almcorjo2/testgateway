/**
 * 
 */
package com.hrs.testapi;

import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author almcorfuegon
 * Oct 29, 2020
 */
@RestController
@CrossOrigin()
public class TestController {

	
	@RequestMapping(value = "/findTest", method = RequestMethod.POST, produces = "application/json")
	public String findSurveyTest(@RequestBody Map<String, Object> Id) {
		System.out.println("Hello World");
		return "Hello World";
	}
}
