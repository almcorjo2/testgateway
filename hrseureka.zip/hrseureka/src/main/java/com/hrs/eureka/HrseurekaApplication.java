package com.hrs.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;


@EnableEurekaServer
@SpringBootApplication
public class HrseurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrseurekaApplication.class, args);
	}

}
