package com.hrs.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrseurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
